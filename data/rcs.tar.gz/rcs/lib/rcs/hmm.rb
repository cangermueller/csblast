module CS
  class ContextProfileState < ContextProfile
    attr_accessor :in_transitions, :out_transitions

    def initialize(ios)
      super
      @in_transitions  = Hash.new(0.0)
      @out_transitions = Hash.new(0.0)
      self
    end

    def in_transition(k)
      @in_transitions[k]
    end

    def out_transition(l)
      @out_transitions[l]
    end

    def read_header(ios)
      super
      if line = ios.gets then @num_states = line.split(/\s+/).last.to_i end
    end
  end

  class Hmm
    include Enumerable

    attr_accessor :num_states, :num_transitions, :num_cols, :iterations, :states, :transitions

    def initialize(ios)
      @states = []
      @transitions = Hash.new(0.0)
      read(ios)
      self
    end

    def [] (k)
      @states[k]
    end

    def state(k)
      @states[k]
    end

    def transition(k,l)
      @transitions[[k,l]]
    end

    def each_state
      @states.each { |s| yield s }
    end
    alias each each_state

    def each_transition
      @transitions.each { |k,v| yield k,v }
    end

    private
    SCALE_FACTOR = 1000

    def read(ios)
      # advance to HMM record
      class_id = self.class.to_s.split('::').last.upcase
      line = ""
      while (line = ios.gets)
        break if line !~ /^\s*$/
      end
      raise "Bad format: serialized HMM does not start with #{class_id}" unless line.strip == class_id

      # read header
      if line = ios.gets then @num_states      = line.split(/\s+/).last.to_i end
      if line = ios.gets then @num_transitions = line.split(/\s+/).last.to_i end
      if line = ios.gets then @num_cols        = line.split(/\s+/).last.to_i end
      if line = ios.gets then @iterations      = line.split(/\s+/).last.to_i end
      ios.gets # skip states logspace
      ios.gets # skip transitions logspace

      # read states
      while (@states.size < @num_states)
        state = ContextProfileState.new(ios)
        @states << state
      end
      raise "HMM has #{@states.size} states but should have #{@num_states}!" if (@states.size != @num_states)

      # read transitions
      ios.gets  # skip description
      while (line = ios.gets)
        break if line[0..1] == "//"
        tokens = line.split(/\s+/)
        k = tokens[0].to_i
        l = tokens[1].to_i
        p = 2.0 ** (-tokens.last.to_f / SCALE_FACTOR)
        @transitions[[k,l]] = p
        @states[k].out_transitions[l] = p
        @states[l].in_transitions[k] = p
      end
      raise "HMM has #{@transitions.size} transitions but should have #{@num_transitions}!" if (@transitions.size != @num_transitions)
    end
  end
end
