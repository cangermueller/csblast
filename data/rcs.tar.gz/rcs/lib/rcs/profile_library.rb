module CS
  class ProfileLibrary
    include Enumerable

    attr_accessor :num_profiles, :num_cols, :profiles

    def initialize(ios)
      @profiles = []
      read(ios)
      self
    end

    def [] (k)
      @profiles[k]
    end

    def each
      @profiles.each { |s| yield s }
    end

    private
    SCALE_FACTOR = 1000

    def read(ios)
      # advance to library record
      class_id = self.class.to_s.split('::').last
      line = ""
      while (line = ios.gets)
        break if line !~ /^\s*$/
      end
      raise "Bad format: serialized profile library does not start with 'ContextLibrary'" unless line.strip == "ContextLibrary"

      # read header
      if line = ios.gets then @num_profiles    = line.split(/\s+/).last.to_i end
      if line = ios.gets then @num_cols        = line.split(/\s+/).last.to_i end

      # read profiles
      while (@profiles.size < @num_profiles)
        profile = ContextProfile.new(ios)
        @profiles << profile
      end
      raise "Profile library has #{@profiles.size} profiles but should have #{@num_profiles}!" if (@profiles.size != @num_profiles)
    end
  end
end
