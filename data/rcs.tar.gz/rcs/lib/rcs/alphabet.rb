require 'singleton'

module CS
  class Alphabet
    include Enumerable

    attr_reader :size, :ctoi, :itoc

    class << self; protected :new; end

    def self.create(size)
      case size
      when 4
        return Nucleotide.instance
      when 20
        return AminoAcid.instance
      else
        raise "Unsupported alphabet!"
      end
    end

    def [] (a)
      @ctoi[a]
    end

    def chr(i)
      @itoc[i]
    end

    def color(a)
      if a.is_a?(Integer)
        @colors[@itoc[a]]
      else
        @colors[a]
      end
    end

    def order(a)
      if a.is_a?(Integer)
        @order[@itoc[a]]
      else
        @order[a]
      end
    end

    def each
      0.upto(@size-1) { |i| yield i }
    end

    def each_chr
      @itoc.each { |a| yield a }
    end

  end

  class Nucleotide < Alphabet
    include Singleton

    def initialize
      @size = SIZE
      @itoc = ALPHABET
      @ctoi = {}
      ALPHABET.each_index { |i|  @ctoi[ALPHABET[i]] = i }
      @colors = COLORS
      @order  = ORDER
    end

    SIZE = 4
    ALPHABET = ['A','C','G','T']
    COLORS = {
      'A' => '#00CC00',
      'C' => '#4169e1',
      'G' => '#FFB300',
      'T' => '#CC0000'
    }
    ORDER = {
      'A' => 1,
      'C' => 2,
      'G' => 3,
      'T' => 4
    }

  end

  class AminoAcid < Alphabet
    include Singleton

    def initialize
      @size = SIZE
      @itoc = ALPHABET
      @ctoi = {}
      ALPHABET.each_index { |i|  @ctoi[ALPHABET[i]] = i }
      @colors = COLORS
      @order  = ORDER
    end

    SIZE = 20
    ALPHABET = ['A','R','N','D','C','Q','E','G','H','I','L','K','M','F','P','S','T','W','Y','V']
    COLORS = {
      'W' => '#00c000',
      'Y' => '#00c000',
      'F' => '#00c000',

      'C' => '#ffff00',

      'D' => '#6080ff',
      'E' => '#6080ff',

      'L' => '#02ff02',
      'I' => '#02ff02',
      'V' => '#02ff02',
      'M' => '#02ff02',

      'K' => '#ff0000',
      'R' => '#ff0000',

      'Q' => '#e080ff',
      'N' => '#e080ff',

      'H' => '#ff8000',

      'P' => '#a0a0a0',

      'G' => '#ffffff',
      'A' => '#ffffff',
      'S' => '#ffffff',
      'T' => '#ffffff'
    }
    ORDER = {
      'A' => 4,
      'C' => 3,
      'D' => 5,
      'E' => 5,
      'F' => 2,
      'G' => 4,
      'H' => 7,
      'I' => 1,
      'K' => 8,
      'L' => 1,
      'M' => 1,
      'N' => 6,
      'P' => 9,
      'Q' => 6,
      'R' => 8,
      'S' => 4,
      'T' => 4,
      'V' => 1,
      'W' => 2,
      'Y' => 2,
    }
  end



end
