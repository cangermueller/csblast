require 'tmpdir'

module CS
  class CrfVisualizer
    include Magick

    attr_accessor :min_transition_weight, :min_profile_prob, :transition_saturation, :filter, :padding

    def initialize()
      @min_transition_weight = -2.5
      @min_profile_prob      = 0.01
      @transition_saturation = 0.8
      @filter                = nil
      @num_states_per_line   = 5
      @padding               = 30

      self
    end

    def draw(crf, outfile)
      viz = CrfStateVisualizer.new
      viz.min_profile_prob = min_profile_prob

      num_cols = [crf.num_states, @num_states_per_line].min
      num_rows = (crf.num_states.to_f / num_cols).ceil

      cell_width  = (crf.num_cols + 3) * viz.col_width + viz.stroke_width - 1
      cell_height = 2 * viz.col_height + viz.ruler_height + viz.stroke_width

      img_width  = num_cols * (cell_width + padding) - padding + 1
      img_height = num_rows * (cell_height + padding) - padding + 1
      canvas = Image.new(img_width, img_height) { self.background_color = "white" }

      x = 0
      y = 0

      bias_max    = 0
      context_max = 0
      crf.each_state do |state|
        bias_max = [bias_max, Math.exp(state.bias_weight)].max
        state.each  do |col|
          context_max = [context_max, col.map {|w| Math.exp(w) }.max].max
        end
      end
      col_sum_max = 0
      crf.each_state do |state|
        state.each  do |col|
          col_sum_max = [col_sum_max, col.inject(0.0) {|sum,w| sum + Math.exp(w) / context_max }].max
        end
      end

      viz.bias_weight_max      = bias_max
      viz.context_weight_max   = context_max
      viz.context_weight_scale = 1.0 / col_sum_max


      crf.each_state do |state|
        viz.draw_state_to_canvas(state, canvas, x, y)

        x += cell_width + padding
        if state.index % num_cols == 0
          y += cell_height + padding
          x = 0
        end
      end

      canvas.write(outfile)
    end

    # def draw(crf, outfile)
    #   crf.each_state do |state|
    #     next if @filter && !@filter.include?(state.index)
    #     pv = CrfStateVisualizer.new
    #     pv.min_profile_prob = min_profile_prob
    #     pv.max_column_weight = 20.0
    #     pv.draw(state, "#{Dir.tmpdir}/state#{state.index}.png")
    #   end

    #   g = GraphViz::new( "structs", "type" => "graph" )
    #   g[:rankdir] = "TB"
    #   g[:overlap] = "false"

    #   g.node[:style]    = "invis"
    #   g.node[:shape]    = "box"
    #   g.node[:penwidth] = "3"
    #   g.node[:fontname] = "Consolas"
    #   g.node[:fontsize] = "18"
    #   g.node[:margin]   = "0.0"

    #   g.edge[:fontsize] = "18"
    #   g.edge[:fontname] = "Consolas"
    #   g.edge[:dir]      = "forward"
    #   g.edge[:arrowsize]= "2.0"
    #   g.edge[:penwidth] = "3"
    #   g.edge[:len]      = "1.5"

    #   crf.each do |state|
    #     next if @filter && !@filter.include?(state.index)
    #     sg = g.add_graph("subgraph_state#{state.index}")
    #     sg.add_node(state.index.to_s)
    #     node = g.add_node(state.index.to_s)
    #     node.label = ""
    #     node.shapefile = "#{Dir.tmpdir}/state#{state.index}.png"
    #   end

    #   wmax = crf.transitions.values.max
    #   wmin = crf.transitions.values.min
    #   crf.each_transition do |tr,w|
    #     if (w >= min_transition_weight &&
    #         (@filter.nil? || (@filter.include?(tr.first) && @filter.include?(tr.last))))
    #       prob = (w - wmin) / (wmax - wmin)

    #       edge = g.add_edge(tr.first.to_s, tr.last.to_s)
    #       sat = (transition_saturation * (1.0 - prob) * 255).round.to_i.to_s(16)
    #       sat = "0"+sat if sat.size==1
    #       edge.color = "##{sat}#{sat}#{sat}"
    #       edge.fontcolor = "##{sat}#{sat}#{sat}"
    #       edge.label = sprintf("%+.1f", w)
    #       edge.label = sprintf("%+.1f", w)
    #       edge.weight = (prob * 100.0).to_s
    #     end
    #   end

    #   g.output( "output" => "png", :file => outfile)

    #   crf.each_state do |state|
    #     next if @filter && !@filter.include?(state.index)
    #     File.delete("#{Dir.tmpdir}/state#{state.index}.png")
    #   end
    # end

  end
end
