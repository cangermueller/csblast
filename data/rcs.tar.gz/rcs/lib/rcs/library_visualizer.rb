require 'rcs/profile_visualizer'

module CS
  class LibraryVisualizer < ProfileVisualizer
    attr_accessor :padding, :num_profiles_per_line

    def initialize()
      @col_width        = 20
      @col_height       = 200
      @ruler_height     = 24
      @stroke_width     = 2
      @font_size        = 28
      @font_family      = "consolas"
      @min_profile_prob = 0.01
      @padding          = 20
      @num_profiles_per_line = 32

      self
    end

    def draw(lib, outfile)
      # img_width  = (lib.num_cols * col_width + @stroke_width - 1 + padding) * lib.num_profiles - padding
      # img_height = col_height + ruler_height + @stroke_width
      # canvas = Image.new(img_width, img_height) { self.background_color = "white" }

      num_cols = [lib.num_profiles, @num_profiles_per_line].min
      num_rows = (lib.num_profiles.to_f / num_cols).ceil

      cell_width  = lib.num_cols * @col_width + @stroke_width - 1
      cell_height = @col_height + @ruler_height + @stroke_width

      img_width  = num_cols * (cell_width + padding) - padding + 1
      img_height = num_rows * (cell_height + padding) - padding + 1
      canvas = Image.new(img_width, img_height) { self.background_color = "white" }

      x = 0
      y = cell_height
      i = 0
      lib.each do |profile|
        draw_profile_to_canvas(profile, canvas, x, y)
        i += 1

        x += cell_width + padding
        if i % num_cols == 0
          y += cell_height + padding
          x = 0
        end
      end

      canvas.write(outfile)
    end

  end
end
