require 'profile'

module CS
  class CountProfile < Profile
    def initialize(ios)
      @profile = []
      @neff    = []
      read(ios)
      self
    end

    def neff(i)
      @neff[i]
    end

    def average_neff
      @neff.inject(0.0) {|sum,n| sum + n } / @neff.size
    end

    private

    def read_body(ios)
      while (line = ios.gets)
        break if line[0..1] == "//"
        tokens = line.split(/\s+/)
        tokens.shift  # discard column number
        @neff << tokens[tokens.size - 1].to_f / 1000
        tokens.delete_at(tokens.size - 1)
        @profile << tokens.map { |v| v == '*' ? 0.0 : 2.0 ** (-v.to_f / 1000) }
      end
      if (@profile.size != @num_cols)
        raise "Bad format: profile has #{@profile.size} columns but should have #{@num_cols}!"
      end
    end

  end
end
