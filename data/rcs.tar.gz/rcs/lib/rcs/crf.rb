module CS
  class CrfState
    include Enumerable

    attr_accessor :index, :num_cols, :alphabet_size, :pc_sum, :bias_weight, :column_weights, :context_weights

    def initialize(ios)
      @context_weights = []
      read(ios)
      self
    end

    def [] (i)
      @context_weights[i]
    end

    def at(i, a)
      @context_weights[i][a]
    end

    def each
      @context_weights.each { |col| yield col }
    end

    def center
      (@num_cols - 1) / 2
    end

    def pc(a)
      Math.exp(@pc[a]) / @pc.inject(0) {|sum,nu| sum + Math.exp(nu) }
    end

    def p(i, a)
      Math.exp(@context_weights[i][a]) / @context_weights[i].inject(0) {|sum,lambda| sum + Math.exp(lambda) }
    end

    private

    def read(ios)
      # advance to profile record
      class_id = self.class.to_s.split('::').last
      line = ""
      while (line = ios.gets)
        break if line !~ /^\s*$/
      end
      raise "Bad format: state does not start with #{class_id}" unless line.strip == class_id

      read_header(ios)
      read_body(ios)
    end

    def read_body(ios)
      ios.gets  # skip alphabet description line
      while (line = ios.gets)
        break if line[0..1] == "//"
        tokens = line.split(/\s+/)
        if (tokens.shift == "PC")  # discard column number
          @pc = tokens.map { |v| v.to_f / 1000 }
        else
          @context_weights << tokens.map { |v| v.to_f / 1000 }
        end
      end
      if (@context_weights.size != @num_cols)
        raise "Bad format: weight matrix has #{@context_weights.size} columns but should have #{@num_cols}!"
      end
    end

    def read_header(ios)
      if line = ios.gets then @index = line.split(/\s+/).last.to_i end
      if line = ios.gets then @bias_weight = line.split(/\s+/).last.to_f end
      if line = ios.gets then @num_cols = line.split(/\s+/).last.to_i end
      if line = ios.gets then @alphabet_size = line.split(/\s+/).last.to_i end
    end
  end

  class Crf
    include Enumerable

    attr_accessor :num_states, :num_cols, :states

    def initialize(ios)
      @states = []
      @transitions = Hash.new(0.0)
      read(ios)
      self
    end

    def [] (k)
      @states[k]
    end

    def state(k)
      @states[k]
    end

    def each_state
      @states.each { |s| yield s }
    end
    alias each each_state

    private
    SCALE_FACTOR = 1000

    def read(ios)
      # advance to HMM record
      class_id = self.class.to_s.split('::').last.upcase
      line = ""
      while (line = ios.gets)
        break if line !~ /^\s*$/
      end
      raise "Bad format: serialized CRF does not start with 'CRF'" unless line.strip == "CRF"

      # read header
      if line = ios.gets then @num_states      = line.split(/\s+/).last.to_i end
      if line = ios.gets then @num_cols        = line.split(/\s+/).last.to_i end

      # read states
      while (@states.size < @num_states)
        state = CrfState.new(ios)
        @states << state
      end
      raise "CRF has #{@states.size} states but should have #{@num_states}!" if (@states.size != @num_states)
    end
  end
end
