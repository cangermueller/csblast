module CS
  class CrfStateVisualizer
    include Magick

    attr_accessor :col_width, :col_height, :ruler_height, :stroke_width, :min_profile_prob, :context_weight_max, :bias_weight_max, :context_weight_scale
    attr_reader :font_size, :font_family

    DARK_BLUE  = "#4D89F9"
    LIGHT_BLUE = "#C6D9FD"
    DARK_RED   = "#B73B3B"
    LIGHT_RED  = "#FFCEBE"
    YELLOW     = "#FFCC33"

    def initialize()
      @col_width         = 20
      @col_height        = 250
      @ruler_height      = 24
      @stroke_width      = 2
      @font_size         = 27
      @font_family       = "consolas"
      @min_profile_prob  = 0.03
      @bias_weight_max   = 1.0
      @context_weight_max   = 100.0
      @context_weight_scale = 0.1

      self
    end

    def draw(state, outfile)
      canvas = Image.new((state.num_cols + 2.5) * col_width + @stroke_width - 1,
                         2 * col_height + ruler_height + @stroke_width) do
        self.background_color = "white"
      end
      draw_state_to_canvas(state, canvas)
      canvas.write(outfile)
    end

    def state_width()
      state.num_cols * col_width + @stroke_width - 1
    end

    def draw_state_to_canvas(state, canvas, x = 0, y = 0)
      draw_upper_bias_weight_column(canvas, x, y  + col_height, state)
      draw_lower_bias_weight_column(canvas, x, y  + col_height + ruler_height, state)
      rectangle(canvas, x, y + col_height, x + col_width, y + col_height + ruler_height, "black", YELLOW)
      text(canvas, x + font_size/8, y + col_height + ruler_height - font_size/8, "B", DARK_RED)

      0.upto(state.num_cols - 1) do |i|
        #draw_profile_column(canvas, x + i * col_width, y + col_height, state, i)
        draw_upper_context_weight_column(canvas, x + (1.5 + i) * col_width, y + col_height, state, i)
        draw_lower_context_weight_column(canvas, x + (1.5 + i) * col_width, y  + col_height + ruler_height, state, i)
      end

      x_left = x + 1.5 * col_width
      rectangle(canvas, x_left,  y + col_height, x_left + state.num_cols * col_width + @stroke_width - 1, y + col_height + ruler_height, "black", "black")
      x_center = state.center * col_width
      rectangle(canvas, x_left + x_center, y + col_height, x_left + x_center + col_width, y + col_height + ruler_height, "black", YELLOW)

      0.upto(state.num_cols - 1) do |i|
        idx = (i-state.center).abs
        text(canvas, x_left + i * col_width + font_size/8, y + col_height + ruler_height - font_size/8, idx, idx == 0 ? DARK_RED : 'white')
      end

      x_right = (state.num_cols + 2) * col_width
      draw_pseudocount_column(canvas, x + x_right, y + col_height, state)
      rectangle(canvas, x + x_right, y + col_height, x + x_right + col_width, y + col_height + ruler_height, "black", YELLOW)
      text(canvas, x + x_right + font_size/8, y + col_height + ruler_height - font_size/8, "P", DARK_RED)
    end

    def draw_pseudocount_column(canvas, x, y, state)
      alphabet = Alphabet.create(state.alphabet_size)
      indices = (0...alphabet.size).to_a
      n = 0
      y_base = y

      indices.sort_by {|a| state.pc(a) }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        prob = state.pc(a)

        if prob >= min_profile_prob
          color = alphabet.color(a)
          bar_height = (col_height.to_f * prob).round.to_i
          rectangle(canvas, x, y_base - bar_height, x + col_width, y_base, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/8, y_aa, alphabet.chr(a))
          end
          y_base -= bar_height
        end
      end
    end

    def draw_column_weight_column(canvas, x, y, state, i)
      bar_height = (col_height.to_f * (1.0 / max_column_weight) * Math.exp(state.col_weight(i))).round.to_i
      bar_height = [col_height, bar_height].min
      rectangle(canvas, x, y, x + col_width, y + bar_height, DARK_BLUE, LIGHT_BLUE)
    end

    def draw_bias_weight_column(canvas, x, y, state)
      bar_height = (col_height.to_f * Math.exp(state.bias_weight) / @bias_weight_max).round.to_i
      bar_height = [col_height, bar_height].min
      rectangle(canvas, x, y, x + col_width, y + bar_height, DARK_RED, LIGHT_RED)
    end

    def draw_context_weight_column(canvas, x, y, state, i)
      alphabet = Alphabet.create(state.alphabet_size)
      indices = (0...alphabet.size).to_a
      n = 0
      y_base = y

      wsum = 0.0
      indices.sort_by {|a| state[i][a] }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        w = context_weight_scale * Math.exp(state[i][a]) / context_weight_max
        if w >= 0.01
          color = alphabet.color(a)
          bar_height = (col_height.to_f * w).round.to_i
          rectangle(canvas, x, y_base, x + col_width, y_base + bar_height, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base + bar_height - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/8, y_aa, alphabet.chr(a))
          end
          y_base += bar_height
        end
      end
    end

    def draw_profile_column(canvas, x, y, state, i)
      alphabet = Alphabet.create(state.alphabet_size)
      indices = (0...alphabet.size).to_a
      n = 0
      y_base = y

      indices.sort_by {|a| state.p(i,a) }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        prob = state.p(i,a)

        if prob >= min_profile_prob
          color = alphabet.color(a)
          bar_height = (col_height.to_f * prob).round.to_i
          rectangle(canvas, x, y_base - bar_height, x + col_width, y_base, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/8, y_aa, alphabet.chr(a))
          end
          y_base -= bar_height
        end
      end
    end

    def draw_upper_bias_weight_column(canvas, x, y, state)
      if (state.bias_weight > min_profile_prob)
        bar_height = (0.1 * col_height.to_f * state.bias_weight).round.to_i
        bar_height = [col_height, bar_height].min
        rectangle(canvas, x, y - bar_height, x + col_width, y, DARK_RED, LIGHT_RED)
      end
    end

    def draw_lower_bias_weight_column(canvas, x, y, state)
      if (-state.bias_weight > min_profile_prob)
        bar_height = (0.1 * col_height.to_f * -state.bias_weight).round.to_i
        bar_height = [col_height, bar_height].min
        rectangle(canvas, x, y, x + col_width, y + bar_height, DARK_RED, LIGHT_RED)
      end
    end

    def draw_upper_context_weight_column(canvas, x, y, state, i)
      alphabet = Alphabet.create(state.alphabet_size)
      indices = (0...alphabet.size).to_a
      n = 0
      y_base = y

      wsum = 0.0
      indices.sort_by {|a| state[i][a] }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        w = 0.1 * state[i][a]

        if w > min_profile_prob
          color = alphabet.color(a)
          bar_height = [col_height, (col_height.to_f * w).round.to_i].min

          rectangle(canvas, x, y_base - bar_height, x + col_width, y_base, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/8, y_aa, alphabet.chr(a))
          end
          y_base -= bar_height
        end
      end
    end

     def draw_lower_context_weight_column(canvas, x, y, state, i)
      alphabet = Alphabet.create(state.alphabet_size)
      indices = (0...alphabet.size).to_a
      n = 0
      y_base = y

      wsum = 0.0
      indices.sort_by {|a| state[i][a] }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        w = 0.1 * -state[i][a]

        if w > min_profile_prob
          color = alphabet.color(a)
          bar_height = [col_height, (col_height.to_f * w).round.to_i].min
          rectangle(canvas, x, y_base, x + col_width, y_base + bar_height, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base + bar_height - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/8, y_aa, alphabet.chr(a))
          end
          y_base += bar_height
        end
      end
    end

    def rectangle(canvas, x1, y1, x2, y2, stroke_color, fill_color = nil)
      gc = Draw.new
      gc.stroke(stroke_color)
      gc.fill(fill_color) if fill_color
      gc.fill_opacity(fill_color ? 1 : 0)
      gc.stroke_width(stroke_width)
      gc.rectangle(x1, y1, x2, y2)
      gc.stroke_antialias(false)
      gc.draw(canvas)
    end

    def text(canvas, x, y, str, color = "black", size = font_size)
      gc = Draw.new
      gc.fill(color)
      gc.pointsize(size)
      gc.font_family(font_family)
      gc.text(x, y, str.to_s)
      gc.draw(canvas)
    end

  end
end
