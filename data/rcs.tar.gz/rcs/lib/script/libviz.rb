#!/usr/bin/env ruby

require 'optparse'
require 'set'

module Script
  class LibViz
    def initialize
      @verbose = true
      @min_profile_prob = 0.01
      @padding = 20
      @sort_by_prior = false
      @num_profiles_per_line = 10
      self
    end

    def parse_options(stdout, args)
      opts = OptionParser.new do |opts|
        opts.banner = <<-BANNER.gsub(/^          /,'')
          Vizualize a context library with profile logos.

          Usage: #{File.basename($0)} -i CRFFILE [options]

          Options are:
        BANNER
        opts.separator ""
        opts.on("-i", "--infile LIBFILE", String, "Input file with serialized context library.") { |arg| @infile = arg }
        opts.on("-o", "--outfile IMAGEFILE", String, "Output file with png image of CRF (def=BASENAME.png).") do |arg|
          @outfile = arg
        end
        opts.on("-p", "--profile-prob PROB", Float, "Minimal emission probability in histograms (def=#{@min_profile_prob}).") do |arg|
          @min_profile_prob = arg
        end
        opts.on("-P", "--padding PROB", Integer, "Padding between profiles (def=#{@padding}).") do |arg|
          @padding = arg
        end
        opts.on("-n", "--num-per-line NUM", Integer, "Number of profiles per line (def=#{@num_profiles_per_line}).") do |arg|
          @num_profiles_per_line = arg
        end
        opts.on("-s", "--sort", "Sort context profiles by descending prior probability") { |v| @sort_by_prior = v }
        opts.on("-h", "--help", "Show this help message.") { stdout.puts opts; return false }
      end
      if args.empty?
        stdout.puts opts
        return false
      end
      opts.parse!(args)

      raise "No input file provided!" unless @infile
      @outfile ||= File.basename(@infile, '.lib') + '.png'

      return true
    end

    def execute(stdout, args=[])
      return unless parse_options(stdout, args)

      puts "Reading context library from #{@infile} ..." if @verbose
      f = File.open(@infile, 'r' )
      lib = CS::ProfileLibrary.new(f)
      if @sort_by_prior
        puts "Sorting profiles ..." if @verbose
        lib.profiles = lib.profiles.sort_by { |p| p.prior }.reverse
      end
      f.close()

      viz = CS::LibraryVisualizer.new
      viz.min_profile_prob = @min_profile_prob
      viz.num_profiles_per_line = @num_profiles_per_line
      viz.padding = @padding
      viz.draw(lib, @outfile)
      puts "Wrote CRF to #{@outfile}" if @verbose
    end

  end
end
