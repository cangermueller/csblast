#!/usr/bin/env ruby

require 'optparse'

module Script
  class ProfViz
    def initialize
      @verbose = true
      @min_profile_prob = 0.01
      self
    end

    def parse_options(stdout, args)
      opts = OptionParser.new do |opts|
        opts.banner = <<-BANNER.gsub(/^          /,'')
          Vizualize one or many profiles with profile logos.

          Usage: #{File.basename($0)} -i PROFILE [options]

          Options are:
        BANNER
        opts.separator ""
        opts.on("-i", "--infile PROFILE", String, "Input file with serialized profile(s).") { |arg| @infile = arg }
        opts.on("-o", "--outfile IMAGEFILE", String, "Output png image with profile logos (def=BASENAME.png).") do |arg|
          @outfile = arg
        end
        opts.on("-p", "--profile-prob PROB", Float, "Minimal probability in histograms (def=#{@min_profile_prob}).") do |arg|
          @min_profile_prob = arg
        end
        opts.on("-h", "--help",
                "Show this help message.") { stdout.puts opts; return false }
      end
      if args.empty?
        stdout.puts opts
        return false
      end
      opts.parse!(args)

      raise "No input file provided!" unless @infile
      @outfile ||= File.basename(@infile, '.prf') + '.png'

      return true
    end

    def execute(stdout, args=[])
      return unless parse_options(stdout, args)

      profiles = []
      f = File.open(@infile, 'r' )
      while !f.eof
        profiles << CS::CountProfile.new(f)
      end
      profiles.uniq!
      f.close()

      viz = CS::ProfileVisualizer.new
      viz.min_profile_prob = @min_profile_prob
      profiles = profiles[0...30]
      viz.draw(profiles, @outfile)
      puts "Wrote profile(s) to #{@outfile}" if @verbose
    end
  end
end
