#!/usr/bin/env ruby

require 'optparse'
require 'set'

module Script
  class CrfViz
    def initialize
      @verbose = true
      @min_transition_weight = 0.0
      @min_profile_prob    = 0.01
      @num_components      = nil
      self
    end

    def parse_options(stdout, args)
      opts = OptionParser.new do |opts|
        opts.banner = <<-BANNER.gsub(/^          /,'')
          Vizualize a context CRF with profile logos and transition weights.

          Usage: #{File.basename($0)} -i CRFFILE [options]

          Options are:
        BANNER
        opts.separator ""
        opts.on("-i", "--infile CRFFILE", String, "Input file with serialized CRF.") { |arg| @infile = arg }
        opts.on("-o", "--outfile IMAGEFILE", String, "Output file with png image of CRF (def=BASENAME.png).") do |arg|
          @outfile = arg
        end
        opts.on("-t", "--transition WEIGHT", Float, "Minimal transition weight (def=#{@min_transition_weight}).") do |arg|
          @min_transition_weight = arg
        end
        opts.on("-p", "--profile-prob PROB", Float, "Minimal emission probability in histograms (def=#{@min_profile_prob}).") do |arg|
          @min_profile_prob = arg
        end
        opts.on("-c", "--connected-comp NUM", Integer, "Print NUM largest connected components (def=off).") { |n| @num_components = n }
        opts.on("-h", "--help", "Show this help message.") { stdout.puts opts; return false }
      end
      if args.empty?
        stdout.puts opts
        return false
      end
      opts.parse!(args)

      raise "No input file provided!" unless @infile
      @outfile ||= File.basename(@infile, '.crf') + '.png'

      return true
    end

    def execute(stdout, args=[])
      return unless parse_options(stdout, args)

      puts "Reading CRF from #{@infile} ..." if @verbose
      f = File.open(@infile, 'r' )
      crf = CS::Crf.new(f)
      f.close()

      if @num_components.nil?
        viz = CS::CrfVisualizer.new
        viz.min_transition_weight = @min_transition_weight
        viz.min_profile_prob    = @min_profile_prob

        viz.draw(crf, @outfile)
        puts "Wrote CRF to #{@outfile}" if @verbose
      else
        comp = calculate_connected_components(crf, @min_transition_weight)
        n = 1
        comp[0...[@num_components,comp.size].min].each do |filter|
          outfile = File.basename(@outfile, '.png') + "_#{n}.png"

          viz = CS::CrfVisualizer.new
          viz.filter = filter
          viz.min_transition_weight = @min_transition_weight
          viz.min_profile_prob      = @min_profile_prob
          viz.draw(crf, outfile)

          puts "Wrote connected component #{n} with #{filter.size} states to #{outfile}" if @verbose
          n += 1
        end
      end
    end

    def calculate_connected_components(crf, min_weight)
      puts "Calculating connected components ..." if @verbose
      components = []

      dg = RGL::DirectedAdjacencyGraph.new
      crf.each_transition do |k,v|
        if v.to_f >= min_weight && v.to_f < 1.0
          dg.add_vertex k.first
          dg.add_vertex k.last
          dg.add_edge k.first, k.last
        end
      end

      dg.to_undirected.each_connected_component() do |c|
        components << c
      end
      puts components.map {|c| c.size }.inspect if @verbose

      return components.to_a.sort_by {|comp| comp.size }.reverse
    end
  end
end
