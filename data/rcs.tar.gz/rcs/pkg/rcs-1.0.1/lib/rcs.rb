$:.unshift(File.dirname(__FILE__)) unless
  $:.include?(File.dirname(__FILE__)) || $:.include?(File.expand_path(File.dirname(__FILE__)))
$:.unshift(File.join(File.dirname(__FILE__), 'rcs'))  # to allow includes without dirname

require 'rubygems'
require 'RMagick'
require 'graphviz'
Dir[File.dirname(__FILE__) + '/**/*.rb'].sort.each { |lib| require lib }

module CS
  VERSION = '1.0.1'
end
