#!/usr/bin/env ruby

require 'optparse'
require 'set'

module Script
  class HMMViz
    def initialize
      @verbose = true
      @min_transition_prob = 0.0
      @min_profile_prob    = 0.01
      @filter              = false
      self
    end

    def parse_options(stdout, args)
      opts = OptionParser.new do |opts|
        opts.banner = <<-BANNER.gsub(/^          /,'')
          Vizualize a context HMM with profile logos and transition probabilities.

          Usage: #{File.basename($0)} -i HMMFILE [options]

          Options are:
        BANNER
        opts.separator ""
        opts.on("-i", "--infile HMMFILE", String, "Input file with serialized HMM.") { |arg| @infile = arg }
        opts.on("-o", "--outfile IMAGEFILE", String, "Output file with png image of HMM.",
                "Default: BASENAME.png") { |arg| @outfile = arg }
        opts.on("-t", "--transition-threshold PROB", Float, "Minimal transition probability.",
                "Default: #{@min_transition_prob}") { |arg| @min_transition_prob = arg }
        opts.on("-p", "--profile-threshold PROB", Float, "Minimal profile probability for inclusion in histogram.",
                "Default: #{@min_profile_prob}") { |arg| @min_profile_prob = arg }
        opts.on("-f", "--filter", "Show only states in largest connected component.") { |f| @filter = f }
        opts.on("-h", "--help",
                "Show this help message.") { stdout.puts opts; return false }
      end
      if args.empty?
        stdout.puts opts
        return false
      end
      opts.parse!(args)

      raise "No input file provided!" unless @infile
      @outfile ||= File.basename(@infile, '.hmm') + '.png'

      return true
    end

    def execute(stdout, args=[])
      return unless parse_options(stdout, args)

      f = File.open(@infile, 'r' )
      hmm = CS::HMM.new(f)
      f.close()

      viz = CS::HMMVisualizer.new
      viz.filter = get_filter(hmm, @min_transition_prob) if @filter
      viz.min_transition_prob = @min_transition_prob
      viz.min_profile_prob    = @min_profile_prob
      viz.draw(hmm, @outfile)
    end

    def get_filter(hmm, min_prob)
      components = (0...hmm.num_states).to_a.to_set.divide do |k,l|
        tr_kl = hmm.transition(k,l)
        tr_lk = hmm.transition(l,k)
        (tr_kl && tr_kl >= min_prob) || (tr_lk && tr_lk >= min_prob)
      end
      return components.to_a.sort_by {|comp| comp.size }.reverse.first
    end
  end
end
