#!/usr/bin/env ruby

require 'optparse'

module Script
  class ProfViz
    def initialize
      @verbose = true
      self
    end

    def parse_options(stdout, args)
      opts = OptionParser.new do |opts|
        opts.banner = <<-BANNER.gsub(/^          /,'')
          Vizualize a full-length profile with profile logos.

          Usage: #{File.basename($0)} -i PROFILE [options]

          Options are:
        BANNER
        opts.separator ""
        opts.on("-i", "--infile PROFILE", String, "Input file with serialized profile.") { |arg| @infile = arg }
        opts.on("-o", "--outfile IMAGEFILE", String, "Output png image with profile logos.",
                "Default: BASENAME.png") { |arg| @outfile = arg }
        opts.on("-h", "--help",
                "Show this help message.") { stdout.puts opts; return false }
      end
      if args.empty?
        stdout.puts opts
        return false
      end
      opts.parse!(args)

      raise "No input file provided!" unless @infile
      @outfile ||= File.basename(@infile, '.prf') + '.png'

      return true
    end

    def execute(stdout, args=[])
      return unless parse_options(stdout, args)

      f = File.open(@infile, 'r' )
      prof = CS::CountProfile.new(f)
      f.close()

      viz = CS::ProfileVisualizer.new
      viz.draw(prof, @outfile)
    end
  end
end
