require 'tmpdir'

module CS
  class HMMVisualizer
    attr_accessor :min_transition_prob, :min_profile_prob, :transition_saturation, :filter

    def initialize()
      @min_transition_prob   = 0.2
      @min_profile_prob      = 0.01
      @transition_saturation = 0.8
      @filter                = nil

      self
    end

    def draw(hmm, outfile)
      hmm.each_state do |state|
        next if @filter && !@filter.include?(state.index)
        pv = ProfileVisualizer.new
        pv.min_profile_prob = min_profile_prob
        pv.draw(state, "#{Dir.tmpdir}/state#{state.index}.png")
      end

      g = GraphViz::new( "structs", "type" => "graph" )
      g[:rankdir] = "LR"
      g[:overlap] = "false"

      g.node[:style]    = "invis"
      g.node[:shape]    = "box"
      g.node[:penwidth] = "3"
      g.node[:fontname] = "Courier-Bold"
      g.node[:fontsize] = "20"
      g.node[:margin]   = "0.0"

      g.edge[:fontsize] = "20"
      g.edge[:fontname] = "Courier-Bold"
      g.edge[:dir]      = "forward"
      g.edge[:arrowsize]= "2.0"
      g.edge[:penwidth] = "3"
      g.edge[:len]      = "1.5"

      hmm.each do |state|
        next if @filter && !@filter.include?(state.index)
        sg = g.add_graph("subgraph_state#{state.index}")
        sg.add_node(state.index.to_s)
        node = g.add_node(state.index.to_s)
        node.label = ""
        node.shapefile = "#{Dir.tmpdir}/state#{state.index}.png"
      end

      hmm.each_transition do |tr,prob|
        if (prob >= min_transition_prob &&
            (@filter.nil? || (@filter.include?(tr.first) && @filter.include?(tr.last))))
          edge = g.add_edge(tr.first.to_s, tr.last.to_s)
          sat = (transition_saturation * (1.0 - prob) * 255).round.to_i.to_s(16)
          sat = "0"+sat if sat.size==1
          edge.color = "##{sat}#{sat}#{sat}"
          edge.fontcolor = "##{sat}#{sat}#{sat}"
          edge.label = sprintf("%-.1f\%", prob * 100.0)
          edge.label = sprintf("%-.1f\%", prob * 100.0)
          edge.weight = (prob * 100.0).to_s
        end
      end

      g.output( "output" => "png", :file => outfile)

      hmm.each_state do |state|
        next if @filter && !@filter.include?(state.index)
        File.delete("#{Dir.tmpdir}/state#{state.index}.png")
      end
    end

  end
end
