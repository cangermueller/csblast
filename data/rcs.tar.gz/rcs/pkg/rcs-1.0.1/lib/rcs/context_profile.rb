require 'profile'

module CS
  class ContextProfile < Profile
    attr_reader :index, :prior

    def initialize(ios)
      @profile = []
      read(ios)
      self
    end

    def center
      (@num_cols - 1) / 2
    end

    private

    def read_header(ios)
      if line = ios.gets then @index = line.split(/\s+/).last.to_i end
      if line = ios.gets then @prior = line.split(/\s+/).last.to_f end
      if line = ios.gets then @num_cols = line.split(/\s+/).last.to_i end
      if line = ios.gets then @alphabet_size = line.split(/\s+/).last.to_i end
      ios.gets  # skip logspace line
    end
  end
end
