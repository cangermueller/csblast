module CS
  class ProfileVisualizer
    include Magick

    attr_accessor :col_width, :col_height, :ruler_height, :stroke_width, :font_family, :font_size, :min_profile_prob

    def initialize()
      @col_width        = 20
      @col_height       = 200
      @ruler_height     = 24
      @stroke_width     = 2
      @font_size        = 28
      @font_family      = "Courier"
      @min_profile_prob = 0.01

      self
    end

    def draw(profile, outfile)
      canvas = Image.new(profile.num_cols * col_width + @stroke_width - 1,
                         col_height + ruler_height + @stroke_width) do
        self.background_color = "white"
      end
      draw_profile_to_canvas(profile, canvas)
      canvas.write(outfile)
    end

    private

    def profile_width()
      profile.num_cols * col_width + @stroke_width - 1
    end

    def draw_profile_to_canvas(profile, canvas, x = 0, y = 0)
      rectangle(canvas,
                x, y + canvas.rows - ruler_height,
                x + profile.num_cols * col_width + @stroke_width - 2, y + canvas.rows - 1,
                "black", "black")

      if profile.is_a?(ContextProfile)
        x_center = profile.center * col_width
        rectangle(canvas,
                  x + x_center, y + canvas.rows - ruler_height,
                  x + x_center + col_width, y + canvas.rows-1,
                  'black', "#FFCC33")

        0.upto(profile.num_cols-1) do |i|
          idx = (i-profile.center).abs
          text(canvas,
               x + i * col_width + font_size/10,
               y + canvas.rows - 1 - font_size/10,
               idx, idx == 0 ? 'red' : 'white')
          draw_column(canvas, x + i * col_width, y + canvas.rows - ruler_height, profile[i])
        end
      else
        0.upto(profile.num_cols-1) do |i|
          idx = (i + 1) % 10
          text(canvas,
               x + i * col_width + font_size/10,
               y + canvas.rows - 1 - font_size/10,
               idx, 'white')
          draw_column(canvas, x + i * col_width, y + canvas.rows - ruler_height, profile[i])
        end
      end
    end

    def draw_column(canvas, x, y, col)
      alphabet = Alphabet.create(col.size)
      indices = (0...alphabet.size).to_a
      n = 0
      sum = 0.0
      y_base = y

      indices.sort_by {|a| col[a] }.reverse.sort_by {|a| n+= 1; [alphabet.order(a), n]}.each do |a|
        prob = col[a]

        if prob >= min_profile_prob
          color = alphabet.color(a)
          bar_height = (col_height.to_f * prob).round.to_i
          rectangle(canvas, x, y_base - bar_height, x + col_width, y_base, 'black', color)
          if bar_height >= 0.75 * font_size
            y_aa = y_base - (bar_height.to_f * 0.5).round.to_i + (font_size * 0.35).round.to_i
            text(canvas, x + font_size/10, y_aa, alphabet.chr(a))
          end
          y_base -= bar_height
        end
      end
    end

    def rectangle(canvas, x1, y1, x2, y2, stroke_color, fill_color = nil)
      gc = Draw.new
      gc.stroke(stroke_color)
      gc.fill(fill_color) if fill_color
      gc.fill_opacity(fill_color ? 1 : 0)
      gc.stroke_width(stroke_width)
      gc.rectangle(x1, y1, x2, y2)
      gc.stroke_antialias(false)
      gc.draw(canvas)
    end

    def text(canvas, x, y, str, color = "black", size = font_size)
      gc = Draw.new
      gc.fill(color)
      gc.pointsize(size)
      gc.font_family(font_family)
      gc.font_weight(800)
      gc.text(x, y, str.to_s)
      gc.draw(canvas)
    end

  end
end
