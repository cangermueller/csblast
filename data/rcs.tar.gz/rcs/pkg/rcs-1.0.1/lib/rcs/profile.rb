module CS
  class Profile
    include Enumerable

    attr_reader :num_cols, :alphabet_size

    def initialize(ios)
      @profile = []
      read(ios)
      self
    end

    def [] (i)
      @profile[i]
    end

    def at(i, a)
      @profile[i][a]
    end

    def each
      @profile.each { |col| yield col }
    end

    private

    def read(ios)
      # advance to profile record
      class_id = self.class.to_s.split('::').last
      line = ""
      while (line = ios.gets)
        break if line !~ /^\s*$/
      end
      raise "Bad format: profile does not start with #{class_id}" unless line.strip == class_id

      read_header(ios)
      read_body(ios)
    end

    def read_body(ios)
      ios.gets  # skip alphabet description line
      while (line = ios.gets)
        break if line[0..1] == "//"
        tokens = line.split(/\s+/)
        tokens.shift  # discard column number
        @profile << tokens.map { |v| v == '*' ? 0.0 : 2.0 ** (-v.to_f / 1000) }
      end
      if (@profile.size != @num_cols)
        raise "Bad format: profile has #{@profile.size} columns but should have #{@num_cols}!"
      end
    end

    def read_header(ios)
      if line = ios.gets then @num_cols = line.split(/\s+/).last.to_i end
      if line = ios.gets then @alphabet_size = line.split(/\s+/).last.to_i end
      ios.gets  # skip logspace line
    end
  end
end
