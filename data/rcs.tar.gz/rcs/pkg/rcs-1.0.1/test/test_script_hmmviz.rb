require File.join(File.dirname(__FILE__), "test_helper.rb")

class TestScriptHMMViz < Test::Unit::TestCase
  def test_not_print_default_output
    stdout_io = StringIO.new
    Script::HMMViz.new.execute(stdout_io, [])
  end
end
