require File.dirname(__FILE__) + '/test_helper.rb'

class TestProfileVisualizer < Test::Unit::TestCase
  def test_draw_count_profile
    File.open(File.dirname(__FILE__) + '/data/zinc_finger.prf', 'r' ) do |f|
      profile = CS::CountProfile.new(f)
      CS::ProfileVisualizer.new.draw(profile, "count_profile.png")
      assert(File.exists?("count_profile.png"))
      File.delete("count_profile.png")
    end
  end

  def test_draw_context_profile
    File.open(File.dirname(__FILE__) + '/data/context_profile.prf', 'r' ) do |f|
      profile = CS::ContextProfile.new(f)
      CS::ProfileVisualizer.new.draw(profile, "profile.png")
      assert(File.exists?("profile.png"))
      File.delete("profile.png")
    end
  end

  def test_draw_hmm_states
    File.open(File.dirname(__FILE__) + '/data/scop20_K100.hhm', 'r' ) do |f|
      hmm = CS::HMM.new(f)
      hmm.each do |state|
        CS::ProfileVisualizer.new.draw(state, "state#{state.index}.png")
        assert(File.exists?("state#{state.index}.png"))
        File.delete("state#{state.index}.png")
      end
    end
  end
end
