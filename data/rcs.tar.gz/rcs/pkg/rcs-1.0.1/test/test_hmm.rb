require File.dirname(__FILE__) + '/test_helper.rb'

class TestHMM < Test::Unit::TestCase
  DELTA = 0.00001

  def test_init
    File.open(File.dirname(__FILE__) + '/data/scop20_K100.hhm', 'r' ) do |f|
      hmm = CS::HMM.new(f)

      assert_equal(100, hmm.num_states)
      assert_equal(100, hmm.states.size)
      assert_equal(869, hmm.num_transitions)
      assert_equal(869, hmm.transitions.size)
    end
  end
end
