require File.dirname(__FILE__) + '/test_helper.rb'

PROFILE = <<EOF
ContextProfile
index\t\t1
prior\t\t0.2
num_cols\t5
alphabet_size\t4
logspace\t0
\tA\tC\tG\tT
1\t0\t*\t*\t*
2\t*\t0\t*\t*
3\t*\t*\t0\t*
4\t*\t*\t*\t0
5\t0\t*\t*\t*
//
EOF

class TestContextProfile < Test::Unit::TestCase

  def test_init_nucleotide_profile
    ios = StringIO.new(PROFILE)
    profile = CS::ContextProfile.new(ios)
    ios.close()

    assert_equal(5, profile.num_cols)
    assert_equal(4, profile.alphabet_size)
    assert_equal(1, profile.index)
    assert_equal(0.2, profile.prior)
    assert_equal(1.0, profile[0][0])
    assert_equal(1.0, profile[1][1])
    assert_equal(0.0, profile[1][0])
  end
end
