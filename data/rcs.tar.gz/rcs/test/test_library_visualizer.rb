require File.dirname(__FILE__) + '/test_helper.rb'

class TestLibraryVisualizer < Test::Unit::TestCase
  def test_draw
    File.open(File.dirname(__FILE__) + '/data/scop20_1.73_opt_N100000_W13.lib', 'r' ) do |f|
      lib = CS::ProfileLibrary.new(f)
      CS::LibraryVisualizer.new.draw(lib, "library.png")
      assert(File.exists?("library.png"))
      File.delete("library.png")
    end
  end
end
