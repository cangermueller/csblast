require File.dirname(__FILE__) + '/test_helper.rb'

class TestCrf < Test::Unit::TestCase
  DELTA = 0.00001

  def test_init
    File.open(File.dirname(__FILE__) + '/data/coiled_coils.crf', 'r' ) do |f|
      crf = CS::Crf.new(f)

      assert_equal(50, crf.num_states)
      assert_equal(50, crf.states.size)
      assert_equal(2500, crf.num_transitions)
      assert_equal(2500, crf.transitions.size)
    end
  end
end
