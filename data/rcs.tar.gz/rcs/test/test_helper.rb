require 'stringio'
require 'test/unit'
$VERBOSE=nil  # quiete graphviz warnings!
require File.dirname(__FILE__) + '/../lib/rcs'
