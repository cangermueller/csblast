require File.dirname(__FILE__) + '/test_helper.rb'

class TestCrfVisualizer < Test::Unit::TestCase
  def test_draw
    File.open(File.dirname(__FILE__) + '/data/coiled_coils.crf', 'r' ) do |f|
      lib = CS::Crf.new(f)
      CS::CrfVisualizer.new.draw(lib, "crf.png")
      assert(File.exists?("crf.png"))
#      File.delete("crf.png")
    end
  end
end
