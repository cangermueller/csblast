require File.dirname(__FILE__) + '/test_helper.rb'

class TestProfileLibrary < Test::Unit::TestCase
  DELTA = 0.00001

  def test_init
    File.open(File.dirname(__FILE__) + '/data/scop20_1.73_opt_N100000_W13.lib', 'r' ) do |f|
      lib = CS::ProfileLibrary.new(f)

      assert_equal(50, lib.num_profiles)
      assert_equal(50, lib.profiles.size)
    end
  end
end
