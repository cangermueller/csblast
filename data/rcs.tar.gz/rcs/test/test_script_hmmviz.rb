require File.join(File.dirname(__FILE__), "test_helper.rb")

class TestScriptHmmViz < Test::Unit::TestCase
  def test_not_print_default_output
    stdout_io = StringIO.new
    Script::HmmViz.new.execute(stdout_io, [])
  end
end
