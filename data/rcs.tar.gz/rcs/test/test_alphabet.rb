require File.dirname(__FILE__) + '/test_helper.rb'

class TestAlphabet < Test::Unit::TestCase

  def test_nucleotode
    na = CS::Alphabet.create(4)
    assert_equal(CS::Nucleotide.instance, na)
    assert_equal(1, na['C'])
    assert_equal('C', na.chr(na['C']))
    assert_equal(4, na.size)
  end

  def test_amino_acid
    aa = CS::Alphabet.create(20)
    assert_equal(CS::AminoAcid.instance, aa)
    assert_equal(4, aa['C'])
    assert_equal('C', aa.chr(aa['C']))
    assert_equal(20, aa.size)

  end
end
